##################################################
import tkinter as tk
from tkinter import *
from tkinter import ttk
import tkinter.font
from tkinter import filedialog
from pytube import YouTube
import os

script_dir = os.path.dirname(__file__)




root = Tk()
label= tk.Label()
root.title('YouTube Converter')

root.geometry('500x500')
root.config(bg='#131417')

root.iconbitmap(os.path.join(script_dir, "YTD.ico"))
print(script_dir)

Desired_font = tkinter.font.Font( family = "Roboto Mono", 
                                 size = 10, 
                                 weight = "bold")
##################################################
def downloadVideo(link):
    vid = YouTube(link)
    dl = vid.streams.get_highest_resolution()
    dl.download(dllocation)

def downloadAudio(link):
    yt = YouTube(link)
    video = yt.streams.filter(only_audio=True).first()
    out_file = video.download(output_path=dllocation)
    base, ext = os.path.splitext(out_file)
    new_file = base + '.mp3'
    os.rename(out_file, new_file)

def downloadOptions():
    if  format(value_inside2.get())==options_list2[1]:
        downloadVideo(link.get())
        ('\a')    
    elif format(value_inside2.get())==options_list2[0]:
        downloadAudio(link.get())
        ('\a')
    link.delete(0, END)

def clickEnter(event):
    downloadOptions()
    link.delete(0, END)

def ClearDownloadLocation():
    global label3
    label3.destroy()
    ChangeDownloadLocation()

def DisplayDownloadLocation():
    global label3
    global dllocation
    dllocation_file = open(os.path.join(script_dir, "dllocation.txt"),"r+") 
    dllocation = dllocation_file.readline()
    dllocation_file.close() 
    label3 = Label(root, text=f"'{dllocation}'",bg='#131417',fg='#fff',font=Desired_font)
    label3.place(x=145,y=60)

def ChangeDownloadLocation():
    global label3
    global dllocation
    dllocation = filedialog.askdirectory()
    dllocation_file = open(os.path.join(script_dir, "dllocation.txt"),"r+") 
    dllocation_file.truncate(0)
    dllocation_file.writelines(dllocation)
    dllocation_file.close()
    DisplayDownloadLocation()
    
label1 = Label(root, text='Enter Video Link: ',bg='#131417',fg='#fff',font=Desired_font)
label1.place(x=10,y=15)
#,width=80
link = Entry(root,width=50,bg='#222222',fg='#fff')
link.place(x=130,y=10,height=30,width=300)

#link.focus_set()

myButton = Button(root, text='Download',command=lambda:[downloadOptions()],bg='#2474a8',fg='#fff',font=Desired_font)
root.bind('<Return>',clickEnter)
#side = RIGHT
myButton.place(x=530,y=8)

options_list2 = {0:"MP3",1:"MP4"}
value_inside2 = tk.StringVar(root)
value_inside2.set(options_list2[0])
question_menu2 = OptionMenu(root,value_inside2, *options_list2.values())    
question_menu2.place(x=440,y=8)
label2 = Label(root, text='Download Location: ',bg='#131417',fg='#fff',font=Desired_font)
label2.place(x=10,y=60)
DisplayDownloadLocation()
myButton2 = Button(root, text='Change',command=lambda:[ClearDownloadLocation()],bg='#2474a8',fg='#fff',font=Desired_font)
myButton2.place(x=35,y=90)
root.mainloop()