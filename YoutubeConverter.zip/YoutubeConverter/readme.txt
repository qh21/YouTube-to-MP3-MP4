- To use the YouTube downloader open (YoutubeConverter.exe) file.

- You can create a shortcut/s of the (YoutubeConverter.exe) file.

- Copy The video link and paste it on the link area (the language of the keyboard must be in English).

- Some videos cannot be downloaded due to the YouTube terms.

